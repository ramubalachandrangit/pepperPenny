'use strict';
window.addEventListener("load", function () {
  var loggedInUserId = 0;
  var loggedInUserName = '';
  var isSignedIn = false;
  var today = moment().startOf("day").valueOf();
  var us_marketplace_id = "ATVPDKIKX0DER";
  var xml_success_responsees = [200, 201, 202, 203, 204, 205, 206, 207, 226];

  chrome.runtime.sendMessage({ action: "showSgcPlugin" });

  var app = angular.module('MerchSalesAnalyser', ['angularModalService', 'ui.utils.masks']);
  var html = document.querySelector('html');
  html.setAttribute('ng-app', '');
  html.setAttribute('ng-csp', '');

  var viewport = document.getElementsByClassName('a-row top-nav-links-container')[0];
  viewport.setAttribute('ng-controller', 'MainController');

  var menuList = document.getElementsByClassName('a-unordered-list a-nostyle a-horizontal a-size-base')[0];

  // add new menu item
  var myLink = document.createElement('li');
  myLink.setAttribute('id', 'sgcDashMenuBtn');
  myLink.setAttribute('class', 'a-align-center top-nav-link-unselected');
  myLink.setAttribute('sgc-menu', '');
  menuList.appendChild(myLink);

  var sgcDashBoard = document.createElement('div');
  sgcDashBoard.setAttribute('sgc-dash-board', '');
  var topNavBarContainer = document.getElementsByClassName('a-row top-nav-bar-container')[0];
  topNavBarContainer.appendChild(sgcDashBoard)

  app.controller('MainController', ['$scope', function ($scope) {
    var sgcDash = getUrlParameter('pepperPenny');
    if (sgcDash) {
      //remove any existing selections
      const menuItems = document.querySelectorAll('.a-unordered-list li')
      for (let i = 0; i < menuItems.length; i++) {
        menuItems[i].setAttribute('class', 'a-align-center top-nav-link-unselected');
      }
      var sgcDashMenuBtn = document.getElementById('sgcDashMenuBtn');
      sgcDashMenuBtn.setAttribute('class', 'a-align-center top-nav-link-selected');

      //remove content below
      var viewportContainer = document.getElementsByClassName('a-row top-nav-bar-container')[0];
      var viewportContainerNexSibling = viewportContainer.nextElementSibling;
      viewportContainerNexSibling.parentNode.removeChild(viewportContainerNexSibling);
    }

    function getUrlParameter(sParam) {
      var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

      for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
          return sParameterName[1] === undefined ? true : sParameterName[1];
        }
      }
    };
  }]);

  app.controller('DashBoardController', ['$scope', 'communicationService', 'ModalService', '$sce', function ($scope, communicationService, ModalService, $sce) {

    var prevoiusDate = new Date();
    //var matchingProducts = [];
    var pageCount = 1;
    var productsAnalysedCount = 0;
    prevoiusDate.setDate(prevoiusDate.getDate() - 90);
    var currentDate = new Date();
    var vendorCode = '';
    var licensedLimit= 0;
    $scope.isLicenseValidated = false;
    $scope.analysisComplete = false;
    $scope.minHistoryDays = 0;
    $scope.salesHistory = [];
    $scope.recentSales = {};
    $scope.salesIncrementalRecommendations = [];
    $scope.salesDecrementalRecommendations = [];
    $scope.isLoaded = false;
    $scope.isLicensed = false;
    $scope.isSgcDashSelected = false;
    $scope.tabActive = 0;
    $scope.lastUpdatedDate;
    $scope.priceRules = [];
    $scope.newRule = {
      id: 0,
      basePrice: 0,
      priceIncrement: 0,
      priceMax: 0,
      daysToWait: 1,
      priceDecrement: 0,
      priceMin: 0
    };

    Init();

    function Init() {
      checkFocus();
    }

    $scope.refresh = function () {
      $scope.isLoaded = false;
      $scope.salesHistory = [];
      loadPriceRules();
    }

    $scope.changeTab = function (id) {
      $scope.tabActive = id;
    };

    
    $scope.savePriceRule = function (form) {
      if (form.$valid) {
        makeWebRequest('rules/SaveRule', "POST", $scope.newRule, function (savedRule) {
          var matchingRule = $scope.priceRules.filter(function (v) { return v.id === savedRule.id; })
          if (matchingRule.length == 0)//adding new Rule
          {
            $scope.priceRules.push(savedRule);
          }
          else {
            var matchIndex = $scope.priceRules.findIndex(x => x.id === savedRule.id);
            $scope.priceRules[matchIndex] = savedRule;
          }
          $scope.newRule = { id: 0, basePrice: 0, priceIncrement: 0, priceMax: 0, daysToWait: 1, priceDecrement: 0, priceMin: 0 };
        });
      }
    };

    $scope.editPriceRule = function (selectedRule) {
      $scope.newRule = angular.copy(selectedRule);
    };

    $scope.deletePriceRule = function (selectedRule) {
      ModalService.showModal({
        templateUrl: $sce.trustAsResourceUrl(chrome.extension.getURL('templates/modal-delete-confirm.html')),
        controller: "DeleteConfirmModal"
      }).then(function (modal) {
        modal.close.then(function (result) {
          if (result == true) {
            var propName = loggedInUserId + "_PriceRules";
            var updatedRules = {};
            var matchIndex = $scope.priceRules.findIndex(x => x.Id === selectedRule.Id);
            $scope.priceRules.splice(matchIndex, 1);
            updatedRules[propName] = $scope.priceRules;
            chrome.storage.local.set(updatedRules, function (result) {
              chrome.extension.sendMessage({ action: "ruleRemoved" }, function (response) {
              });
            });
          }
        });
      });
    };

    $scope.onCancelEdit = function () {
      $scope.newRule = { Id: 0, BasePrice: 0, PriceIncrement: 0, PriceMax: 0, DaysToWait: 1, PriceDecrement: 0, PriceMin: 0 };
    };

    $scope.dismissRecommendation = function (item) {
      item.dismiss = true;
    };

    function getVendorInfo() {
      communicationService.makeWebRequest("https://merch.amazon.com/accountSummary", 'GET', {}, function (data) {
        vendorCode = data.vendorCode;
        validateLicense();
      }, function () { }, false, true);
    }

    function validateLicense() {
      makeWebRequest('authentication/ValidateLicense', "POST", { VendorCode: vendorCode }, function (response) {
        if (response.isLicensed) {
          $scope.isLicensed = true;
          licensedLimit = response.limit;
          setToken(response.token);
          loadPriceRules();
        } else {
          $scope.isLicensed = false;
          $scope.showUpdateProModal();
        }
        $scope.isLicenseValidated = true;
      });
    };

    $scope.showUpdateProModal = function () {
      ModalService.showModal({
        templateUrl: $sce.trustAsResourceUrl(chrome.extension.getURL('templates/modal-upgrade-pro.html')),
        controller: "UpdateProModal",
        inputs: { payLoad: { vendorCode: vendorCode } }
      }).then(function (modal) {
        modal.close.then(function (result) {
            if(result.Status)
            {
              $scope.isLicensed = true;
              licensedLimit = result.Data.limit;
              setToken(result.Data.token);
              loadPriceRules();
            }
        });
      });
    };

    function buildPriceIncreaseRecommendations() {
      $scope.salesIncrementalRecommendations = [];
      $scope.salesDecrementalRecommendations = [];
      getProductList(500, 0);
    };

    function getProductList(pageSize, pageNumber) {
      if (pageNumber < pageCount) {
        if (pageNumber == 0) {
          pageNumber = 1;
        }
        communicationService.makeWebRequest("https://merch.amazon.com/merchandise/list?pageSize=" + pageSize + "&pageNumber=" + pageNumber + "&statusFilters%5B%5D=Live&keywords=", 'GET', {}, function (data) {
          var totalProductsCount = data.totalMerchandiseCount;
          var products = data.merchandiseList;
          pageCount = parseInt(totalProductsCount / 500);
          products.forEach(function (product, productKey) {
            if (typeof product.marketplaceAsinMap.US != 'undefined') {
              var saleInfo = [];
              var matchingRule = $scope.priceRules.filter(function (r) {
                return "$" + r.BasePrice == product.listPrice; // Filter out the appropriate one
              })
              if (matchingRule.length > 0) {
                var minDate = moment().startOf("day").subtract(matchingRule[0].DaysToWait, "days").format("MM/DD/YY");
                var matchingSalesData = $scope.salesHistory.filter(function (v) {
                  return v.sales_date >= minDate; // Filter out the appropriate one
                })

                matchingSalesData.forEach(function (saleData) {
                  var match = saleData.product_list.filter(function (p) {
                    return product.marketplaceAsinMap.US === p.asin;
                  });
                  if (match.length > 0) {
                    match.forEach(function (item) {
                      saleInfo.push(item);
                    });
                  }
                });

                if (saleInfo.length > 0) {
                  var netSold = 0
                  saleInfo.forEach(function (item) {
                    netSold = netSold + item.net_sold;
                  });
                  //check this product has nay previous recommendation history
                  var previousRecommendation = $scope.previousRecommendations.filter(function (r) {
                    return r.productId == product.id;
                    // && r.price != product.listPrice; // Filter out the appropriate one
                  })

                  if (previousRecommendation.length > 0) {
                    var newSalesCount = netSold - previousRecommendation[0].totalSold;
                    var priceMultiplier = 0;

                    if (previousRecommendation[0].price == product.listPrice) {
                      priceMultiplier = newSalesCount + previousRecommendation[0].netSold;
                    }
                    else {
                      priceMultiplier = newSalesCount;
                    }
                    if (priceMultiplier >= matchingRule[0].SaleCount) {
                      var salesRecommend = new Object();
                      salesRecommend.asin = product.marketplaceAsinMap.US;
                      salesRecommend.id = previousRecommendation[0].id;
                      salesRecommend.productId = product.id;
                      salesRecommend.asinName = product.name;
                      salesRecommend.productType = product.shirtType;
                      salesRecommend.price = product.listPrice;
                      salesRecommend.direction = 'up';
                      salesRecommend.dismiss = false;
                      salesRecommend.netSold = priceMultiplier;
                      salesRecommend.totalSold = netSold;
                      var recommendedPrice = matchingRule[0].BasePrice + (priceMultiplier * matchingRule[0].PriceIncrement);
                      if (recommendedPrice > matchingRule[0].PriceMax) {
                        recommendedPrice = matchingRule[0].PriceMax
                      }
                      salesRecommend.priceRecommendation = saleInfo[0].revenueSymbol + recommendedPrice.toFixed(2);
                      if (salesRecommend.priceRecommendation != salesRecommend.price) {
                        $scope.salesIncrementalRecommendations.push(salesRecommend);
                        //update saved recommendation (update product totalsalecount and price )
                        saveRecommendation({
                          Id: salesRecommend.id,
                          ProductId: salesRecommend.productId,
                          PriceRecommendation: salesRecommend.priceRecommendation,
                          TotalSold: salesRecommend.totalSold,
                          NetSold: salesRecommend.netSold,
                          Price: salesRecommend.price
                        });
                      }
                    }
                  }
                  else {
                    if (netSold >= matchingRule[0].SaleCount && matchingRule[0].SaleCount > 0) {
                      var priceMultiplier = parseInt(netSold / matchingRule[0].SaleCount);
                      var salesRecommend = new Object();
                      salesRecommend.asin = product.marketplaceAsinMap.US;
                      salesRecommend.id = 0;
                      salesRecommend.productId = product.id;
                      salesRecommend.asinName = product.name;
                      salesRecommend.productType = product.shirtType;
                      salesRecommend.price = product.listPrice;
                      salesRecommend.direction = 'up';
                      salesRecommend.dismiss = false;
                      salesRecommend.netSold = netSold;
                      salesRecommend.totalSold = netSold;
                      var recommendedPrice = matchingRule[0].BasePrice + (priceMultiplier * matchingRule[0].PriceIncrement);
                      if (recommendedPrice > matchingRule[0].PriceMax) {
                        recommendedPrice = matchingRule[0].PriceMax
                      }
                      salesRecommend.priceRecommendation = saleInfo[0].revenueSymbol + recommendedPrice.toFixed(2);
                      if (salesRecommend.priceRecommendation != salesRecommend.price) {
                        $scope.salesIncrementalRecommendations.push(salesRecommend);
                        //save recommendation 
                        saveRecommendation({
                          Id: salesRecommend.id,
                          ProductId: salesRecommend.productId,
                          PriceRecommendation: salesRecommend.priceRecommendation,
                          TotalSold: salesRecommend.totalSold,
                          NetSold: salesRecommend.netSold,
                          Price: salesRecommend.price
                        });
                      }
                    }
                  }
                }
                else {
                  var salesRecommend = new Object();
                  salesRecommend.asin = product.marketplaceAsinMap.US;
                  salesRecommend.id = 0;
                  salesRecommend.productId = product.id;
                  salesRecommend.asinName = product.name;
                  salesRecommend.productType = product.shirtType;
                  salesRecommend.price = product.listPrice;
                  salesRecommend.direction = 'down';
                  salesRecommend.dismiss = false;
                  salesRecommend.netSold = 0;
                  var recommendedPrice = matchingRule[0].BasePrice - (1 * matchingRule[0].PriceDecrement);
                  if (recommendedPrice < matchingRule[0].PriceMin) {
                    recommendedPrice = matchingRule[0].PriceMin
                  }
                  salesRecommend.priceRecommendation = "$" + recommendedPrice.toFixed(2);
                  if (salesRecommend.priceRecommendation != salesRecommend.price) {
                    $scope.salesDecrementalRecommendations.push(salesRecommend);
                  }
                }               
              }
            }
          });
          productsAnalysedCount = productsAnalysedCount+500;
          if( productsAnalysedCount <= licensedLimit || licensedLimit ==0 )
          {
            getProductList(500, pageNumber + 1);
          }
          else{
            $scope.analysisComplete =true;
            $scope.isLoaded = true;
          }
         
        }, function (error) {
          $scope.analysisComplete =true;
          $scope.isLoaded = true;
         }, false, true);
      }
    };

    function saveRecommendation(recommendation) {
      if ($scope.isLicensed) {
        makeWebRequest('recommendation/SaveRecommendation', "POST", recommendation, function (response) {
          console.log("Updated Recommendation");
        });
      }
    };

    function loadPriceRules() {
      makeWebRequest('rules/GetRules', "GET", {}, function (response) {
        if (response) {
          $scope.priceRules = response.rules;
        } else {
          $scope.priceRules = [];
        }
        loadSavedRecommendations();
      });
    };

    function loadSavedRecommendations() {
      makeWebRequest('recommendation/GetRecommendations', "GET", {}, function (response) {
        $scope.previousRecommendations = response.recommendations;
        synchData();
      });
    };

    function synchData() {  
      chrome.storage.sync.get([loggedInUserId + '_LastUpdatedDate'], function (result) {
        var now = moment();
        var synchFromDate;
        if ($scope.priceRules.length == 0) {
          $scope.minHistoryDays = 14;
        }
        else {
          $scope.minHistoryDays = Math.max.apply(Math, $scope.priceRules.map(function (o) { return o.DaysToWait; }));
        }

        if ($scope.minHistoryDays < 14) {
          $scope.minHistoryDays = 14;
        }
        else if ($scope.minHistoryDays > 90) {
          $scope.minHistoryDays = 89;
        }
        synchFromDate = moment().startOf("day").subtract($scope.minHistoryDays, "days");

        syncSalesData(synchFromDate, function (newSalesData) {
          newSalesData.forEach(function (value, key, myArray) {
            var matchIndex = $scope.salesHistory.findIndex(x => x.sales_date === value.sales_date);
            if (matchIndex >= 0) {
              $scope.salesHistory[matchIndex] = value;
            }
            else {
              $scope.salesHistory.push(value);
            }
          });
          removeSalesHistoryBefore90Days();
          updateLastSyncDate(now);
          buildPriceIncreaseRecommendations();
        });

      });
    };

    function syncSalesData(fromdate, callback) {
      var currentDate = moment();
      var numberOfDays = currentDate.diff(fromdate, 'days');
      var requestCount = numberOfDays + 1;
      var salesArrayIndex = 0;
      var salesData = [];
      for (var index = numberOfDays; index >= 0; index--) {
        var dateInContext = moment(currentDate).subtract(index, "days");
        getSalesData(dateInContext, index, salesArrayIndex, callback);
        salesArrayIndex += 1;
      }

      function getSalesData(date, index, salesArrayIndex, callback) {
        communicationService.makeWebRequest("https://merch.amazon.com/product-purchases-records?fromDate=" + date + "&toDate=" + date, 'GET', {},
          function (data) {
            requestCount -= 1;
            var salesInfo = new Object();
            var t = 0;
            var J = 0;
            var K = 0;
            var w = 0;
            var D = 0;
            var H = 0;
            var C = [];
            var u = {};
            Object.keys(data).forEach(function (Q) {
              u = data[Q][us_marketplace_id][0];
              t += parseInt(u.unitsSold);
              J += parseInt(u.unitsCancelled);
              K += parseInt(u.unitsReturned);
              w += parseFloat(u.revenueValue);
              D += parseFloat(u.royaltyValue);
              u.net_sold = u.unitsSold - u.unitsCancelled;
              C[H] = u;
              ++H
            });
            w = w.toFixed(2);
            D = D.toFixed(2);
            salesInfo.sales_date = date.format("MM/DD/YY");
            salesInfo.total_sales = t;
            salesInfo.total_returned = K;
            salesInfo.total_cancelled = J;
            salesInfo.net_sales = t - J;
            salesInfo.total_revenue = w;
            salesInfo.total_royalties = D;
            salesInfo.product_list = C.sort(function (R, Q) {
              return Q.net_sold - R.net_sold
            });
            findVariationTotals(salesInfo.product_list, function (Q) {
              salesInfo.product_list = Q.product_list;
              salesInfo.variation_totals = Q.variation_totals;
            });
            salesData[salesArrayIndex] = salesInfo;
            if (requestCount == 0) {
              callback(salesData);
            }
          },
          function () {
          }, false, true);
      }
    };

    function removeSalesHistoryBefore90Days() {
      while ($scope.salesHistory.length > 90) {
        $scope.salesHistory.shift()
      }
    };

    function updateLastSyncDate(newDate) {
      var propName = loggedInUserId + "_LastUpdatedDate";
      var payLoad = {};
      payLoad[propName] = newDate.startOf("day").valueOf();
      chrome.storage.sync.set(payLoad, function (result) { });
    };

    function checkFocus() {
      var sgcDash = getUrlParameter('pepperPenny');
      if (sgcDash) {
        $scope.isSgcDashSelected = true;
        getVendorInfo();
        //loadPurchaseRecords();
      }
    };

    function findVariationTotals(h, d) {
      var m = {};
      var a = {};
      var t = 0;
      m.product_list = [];
      m.variation_totals = {};
      m.variation_totals.fitType = [];
      m.variation_totals.color = [];
      m.variation_totals.size = [];
      m.variation_totals.productType = [];
      var p = {};
      var r = {};
      var n = {};
      var g = {};
      for (var x = 0; x < h.length; ++x) {
        a = jQuery.extend(true, {}, h[x]);
        a.variation_totals = {};
        a.variation_totals.fitType = [];
        a.variation_totals.color = [];
        a.variation_totals.size = [];
        a.variation_totals.productType = [];
        var b = {};
        var s = {};
        var o = {};
        var l = {};
        if (a.net_sold > 0 || a.unitsReturned > 0) {
          if (a.productType.toLowerCase() == "popsockets") {
            l.popsockets = a.net_sold;
            g.popsockets = (g.popsockets ? g.popsockets : 0) + a.net_sold
          } else {
            for (var i = 0; i < a.variationRecords.length; i++) {
              var q = a.variationRecords[i].unitsSold - a.variationRecords[i].unitsCancelled;
              if (q > 0) {
                var c = a.variationRecords[i].variationInfo[0].replace(/\s+/g, "_").toLowerCase();
                b[c] = (b[c] ? b[c] : 0) + q;
                p[c] = (p[c] ? p[c] : 0) + q;
                var e = a.variationRecords[i].variationInfo[2].replace(/\s+/g, "_").toLowerCase();
                s[e] = (s[e] ? s[e] : 0) + q;
                n[e] = (n[e] ? n[e] : 0) + q;
                var f = a.variationRecords[i].variationInfo[1].replace(/\s+/g, "_").toLowerCase();
                o[f] = (o[f] ? o[f] : 0) + q;
                r[f] = (r[f] ? r[f] : 0) + q;
                var u = a.variationRecords[i].productType.replace(/\s+/g, "_").toLowerCase();
                l[u] = (l[u] ? l[u] : 0) + q;
                g[u] = (g[u] ? g[u] : 0) + q
              }
            }
          }
          Object.keys(b).forEach(function (j) {
            a.variation_totals.fitType.push({
              variation: j,
              total: b[j]
            })
          });
          Object.keys(s).forEach(function (j) {
            a.variation_totals.color.push({
              variation: j,
              total: s[j]
            })
          });
          Object.keys(o).forEach(function (j) {
            a.variation_totals.size.push({
              variation: j,
              total: o[j]
            })
          });
          Object.keys(l).forEach(function (j) {
            a.variation_totals.productType.push({
              variation: j,
              total: l[j]
            })
          });
          delete a.variationRecords;
          m.product_list[t] = jQuery.extend(true, {}, a);
          ++t
        }
      }
      Object.keys(p).forEach(function (j) {
        m.variation_totals.fitType.push({
          variation: j,
          total: p[j]
        })
      });
      Object.keys(n).forEach(function (j) {
        m.variation_totals.color.push({
          variation: j,
          total: n[j]
        })
      });
      Object.keys(r).forEach(function (j) {
        m.variation_totals.size.push({
          variation: j,
          total: r[j]
        })
      });
      Object.keys(g).forEach(function (j) {
        m.variation_totals.productType.push({
          variation: j,
          total: g[j]
        })
      });
      if (typeof d === "function") {
        d(m)
      }
    };

    function getUrlParameter(sParam) {
      var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

      for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
          return sParameterName[1] === undefined ? true : sParameterName[1];
        }
      }
    };

    function setToken(token) {
      var d = new Date();
      d.setTime(d.getTime() + (1 * 24 * 60 * 60 * 1000));
      var expires = "expires=" + d.toUTCString();
      document.cookie = "X-Token" + "=" + token + ";" + expires + ";path=/";
    };

  }]);

  app.controller('UpdateProModal', ['$scope', 'close', 'payLoad', 'communicationService', function ($scope, close, payLoad, communicationService) {
    $scope.display = true;
    $scope.errorLicence = false;
    $scope.isLoadingKey = false;
    $scope.License = { Key: '' };
    var vendorCode = payLoad.vendorCode;

    $scope.close = function () {
      $scope.display = false;
      close({ Status: false, Data: null });
    };

    $scope.saveLicense = function () {
      if ($scope.License.Key.trim()) {
        $scope.isLoadingKey = true;
        makeWebRequest('authentication/ActivateLicense', "POST", { VendorCode: vendorCode, Key: $scope.License.Key }, function (response) {
          if (response.isSuccess) {
            $scope.display = false;
            close({ Status: true, Data: response });
          } else {
            close({ Status: false, Data: null });
            $scope.errorLicence = true;
            $scope.isLoadingKey = false;
          }
        });
      }
    };

  }]);

  app.controller('DeleteConfirmModal', ['$scope', 'close', function ($scope, close) {
    $scope.display = true;

    $scope.no = function () {
      $scope.display = false;
      close(false);
    };

    $scope.yes = function () {
      $scope.display = false;
      close(true);
    };

    $scope.close = function () {
      $scope.display = false;
      close(false);
    };

  }]);

  app.factory('communicationService', ["$http", function ($http) {
    var onWebrequestEnd = function (callback, errorCallback, response, success) {
      if (success) {
        callback(response);
      } else {
        if (errorCallback) {
          errorCallback(response);
        } else {
          console.log('internal server error, show alert message');
        }
      }
    };

    var communicationService = {};
    communicationService.makeWebRequest = function (url, operation, contextData, callback, errorCallback) {
      var responsePromise;
      switch (operation) {
        case "GET":
          responsePromise = $http.get(url);
          break;
        case "POST":
          responsePromise = $http.post(url, contextData);
          break;
      };

      responsePromise.then(function (response) {
        onWebrequestEnd(callback, errorCallback, response.data, true);
      },
        function (error) {
          onWebrequestEnd(callback, errorCallback, error, false);
        });
    };
    return communicationService;
  }]);

  app.directive('sgcMenu', function () {
    return {
      restrict: 'EA',
      replace: true,
      template: '<li class="a-align-center top-nav-link-unselected"><span class="a-list-item"><a class="a-link-normal" href="/dashboard?pepperPenny">Pepper Penny</a></span></li>'
    };
  });

  app.directive('sgcDashBoard', ['$sce', function ($sce) {
    return {
      restrict: 'EA',
      replace: true,
      templateUrl: $sce.trustAsResourceUrl(chrome.extension.getURL('templates/dashboard.html'))
    };
  }]);

  angular.bootstrap(html, ['MerchSalesAnalyser'], []);
});