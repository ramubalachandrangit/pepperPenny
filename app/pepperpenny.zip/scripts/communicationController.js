﻿// Make GET/POST http Ajax request
function makeWebRequest(url, operation, contextData, callback, errorCallback,busyIndicator) {

    // url concatenating with the base url.
    url = getApiURL() + url;

    
    // If the hideBusyIndicator is not passed from the caller,
    // set it as false for displaying the busyIndicator for web request.
    if (busyIndicator===undefined)
        busyIndicator = true;
    
    //Executes on starting of a web request.
    onWebRequestStart(busyIndicator);
    
    // Make GET/POST http Ajax request according to the operation type
    switch (operation) {
        case "GET":
            // Make GET http Ajax request
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: url,
                data: contextData,
                headers: {
                    "X-Token": getToken()
                },
                dataType: "json",
                success: function (response) { onWebrequestEnd(callback, errorCallback, response, true, busyIndicator); },
                error: function (response) { onWebrequestEnd(callback, errorCallback, response, false, busyIndicator); }
            }
              );
            break;
        case "POST":

            // Make POST http ajax request
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: url,
                headers: {
                    "X-Token": getToken()
                },
                data: JSON.stringify(contextData),
                dataType: "json",
                success: function (response) { onWebrequestEnd(callback, errorCallback, response, true, busyIndicator); },
                error: function (response) { onWebrequestEnd(callback, errorCallback, response, false, busyIndicator); }
            });
            break;
        case "PUT":

            // Make PUT http ajax request
            $.ajax({
                type: "PUT",
                contentType: "application/json; charset=utf-8",
                url: url,
                headers: {
                    "X-Token": getToken()
                },
                data: JSON.stringify(contextData),
                dataType: "json",
                success: function (response) { onWebrequestEnd(callback, errorCallback, response, true, busyIndicator); }
            });
            break;
        case "DELETE":
            $.ajax({
                type: "DELETE",
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(contextData),
                url: url,
                headers: {
                    "X-Token": getToken()
                },
                statusCode: {
                    200: function (response) {
                        // Handles the DELETE web method end.
                        onWebrequestEnd(callback, errorCallback, response, true, busyIndicator);
                    }
                }
            });
            break;
    }
}


var getApiURL =function(){

     //return "https://iberjoya.sgcagency.com/peppepennyapi/api/";
     return "https://iberjoya.sgcagency.com/PepperPennyApiDev/api/";
};

// Method to execute before starting of a web request.
var onWebRequestStart = function (busyIndicator) {

    // To show the busy indicator on starting of a web request if the busyIndicator flag is true.
    if (busyIndicator)
        showBusyIndicator();
};

// The method to execute at the end of a web request.
var onWebrequestEnd = function (callback, errorCallback, response, success, busyIndicator) {

    // To hide the busy indicator.
    if (busyIndicator != undefined && busyIndicator!=false)
        hideBusyIndicator();

    if (success) {
        // WebRequest is success
        // call the success callback
        callback(response);
    }
    else {
        // WebRequest is failed
        // call the error callback
        if (errorCallback) {
            errorCallback(response);
        }
        else {
            // internal server error, show alert message.
            showInternalServerError();
        }
    }
};

// To show the busy indicator while page is in progress.
var showBusyIndicator = function () {

};

// To hide the busy Indicator.
var hideBusyIndicator = function (callback) {

  
};

// Show Internal Server errors.
var showInternalServerError = function () {
    console.log('Internal Server Error');
};

var getToken = function() {
    var name = "X-Token" + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
