'use strict';
var isSignedIn = false;
var loggedInUserId = 0;
var loggedInUserName = 0;

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  var notification = null;
  switch (request.action) {
    case "showSgcPlugin":
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.pageAction.show(tabs[0].id);
      });
      break;
    case "sendLoggedInUserId":
      sendResponse({ userId: loggedInUserId, userName: loggedInUserName, signedIn: isSignedIn });
      break;
    case "ruleSaved":
      notification = {
        type: "basic",
        isClickable: false,
        requireInteraction: false,
        iconUrl: "images/penny-logo-icon.png",
        title: "Pepper Penny",
        message: "Rule Saved Succesfully"
      };
      break;
    case "ruleRemoved":
      notification = {
        type: "basic",
        isClickable: false,
        requireInteraction: false,
        iconUrl: "images/penny-logo-icon.png",
        title: "Pepper Penny",
        message: "Rule Removed Succesfully"
      };
      break;
    case "rulesEmpty":
      notification = {
        type: "basic",
        isClickable: false,
        requireInteraction: false,
        iconUrl: "images/penny-logo-icon.png",
        title: "Pepper Penny",
        message: "No saved rules. Kindly create atleast one.."
      };
      break;
    case "noLicense":
      if (loggedInUserId == 0 || isSignedIn == false) {
        notification = {
          type: "basic",
          isClickable: false,
          requireInteraction: false,
          iconUrl: "images/penny-logo-icon.png",
          title: "Pepper Penny",
          message: "Seems Offline..Kindly Sign in to chrome"
        };
      }
      break;
    default:
      notification = null;
  }
  if (notification != null) {
    //chrome.notifications.create(notification, function (d) { });
  }
});

chrome.identity.getProfileUserInfo(function (info) {
  if (typeof info.id != "undefined" && info.id != "") {
    loggedInUserId = info.id;
    loggedInUserName = info.email
    var getProfileUserInfo = {
      type: "basic",
      isClickable: false,
      requireInteraction: false,
      iconUrl: "images/penny-logo-icon.png",
      title: "Pepper Penny",
      message: " Welcome " + info.email
    };
    //chrome.notifications.create(getProfileUserInfo, function (d) { });
  } else {
    loggedInUserId = 0;
  }
});

chrome.identity.getAuthToken({ interactive: false }, function (token) {
  if (!token) {
    if (chrome.runtime.lastError.message.match(/not signed in/)) {
      isSignedIn = false;
      var getAuthToken = {
        type: "basic",
        isClickable: false,
        requireInteraction: false,
        iconUrl: "images/penny-logo-icon.png",
        title: "Pepper Penny",
        message: "Seems Offline..Kindly Sign in to chrome"
      };
      //chrome.notifications.create(getAuthToken, function (d) { });
      console.log("not singed in");
    } else {
      isSignedIn = true;
      console.log("singed in");
    }
  }
});